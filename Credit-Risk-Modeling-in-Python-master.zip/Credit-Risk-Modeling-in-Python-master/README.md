# Credit-Risk-Modeling-in-Python
I have modeled the credit risk associated with consumer loans. The jupyter notebook contains detailed explanation with comments, 
code and visualizations. 

List of dummy variables is a file which contains dummy variables for all original variables (discrete and continuous) which is used for analysis.

List of reference variables is a file which contains reference variables for all original variables (discrete and continuous). This helps
in comparing the performance of the dummy variables with a reference. 
